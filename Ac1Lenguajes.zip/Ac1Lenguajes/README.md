# README

## Nombres
Sara Castrillón Sánchez, Isabel Acevedo Acosta

## Numero de clase
 Clase SI2002-2 (7309) clase del miercoles

## Desarrollo

- **Sistema Operativo:**: macOS 13
- **Lenguaje:** Phyton 3.x
- **Herramientas utilizadas:** 
  - Visual Studio Code
  - Interprete de Python 3.x

## Instrucciones de Ejecución

1. Descargar o clonar
2. tener instalado Python 3
3. Ejecutar, y abrir la terminal donde está el archivo `"minimize_dfa.py"
4. Poner la entrada

## Explicacion del algoritmo
Este codigo minimiza un DFA encontrando pares de estados equivalentes, estados que para cualquier cadena de entrada se comportan igual (aceptan o rechazan). 

1. **Función parse_input()**
Lee y procesa la entrada que se ingresa,despues lee el número de casos (cuántos DFAs se van a procesar).
Para cada caso, lee el número de estados, los símbolos del alfabeto, los estados finales, y la tabla de transiciones, donde cada línea contiene el identificador de un estado seguido de sus transiciones.
Estructura los datos de entrada para que el resto del programa pueda usar para la minimización.
2. **Función initialize_mark_table(n, final_states)**
Crea una matriz para marcar pares de estados que se consideran distinguibles.
Qué hace:
Crea una matriz de tamaño nxn inicializada en False.
Marca (pone en True) cada par (i,j) donde un estado es final y el otro no, ya que esos dos no pueden ser equivalentes.
Determinar qué pares de estados se diferencian  por ser o no ser estados finales.
3. **Función fill_mark_table(n, alphabet, transition_table, table)**
Esto completa la tabla de marcación usando el metodo de la tabla de llenado.
Recorre los pares de estados no marcados (los que podrían ser equivalentes).
Para cada par y para cada símbolo del alfabeto, revisa las transiciones de ambos estados.
Si las transiciones conducen a otro par de estados que ya están marcados como distinguibles, entonces marca el par actual.
Se repite hasta que no se marquen más pares.
Sirve para que se detecten diferencias sutiles entre estados que inicialmente parecían equivalentes, aplicando la idea de que si las transiciones llevan a estados que se diferencian, entonces los estados originales también deben diferenciarse.
4. **Función get_equivalent_pairs(n, table)**
Saca los pares de estados que no fueron marcados en la tabla, es decir, los estados equivalentes.
Recorre la tabla de marcación y recoge todos los pares (i,j) siempre que i sea mayor a j y que todavia no estan marcados(False)
 Estos son los pares de estados que pueden considerarse equivalentes y, por tanto, candidatos a fusionarse en un DFA minimizado.
5. **Función main()**
 Coordina la ejecución del programa.
Llama a parse_input() para leer la entrada.
Para cada caso, inicializa la tabla de marcación, la llena para marcar pares distinguibles y obtiene los pares equivalentes.
Después imprime los resultados  
 Es el punto del programa que une todas las partes y garantiza que el procesamiento se realice bien.

