

def parse_input():
    """
    Parsea la entrada directamente desde la consola con llamadas a input().
    Formato esperado:
      1) Un número c: la cantidad de casos.
      Para cada caso:
         2) Un entero n: número de estados.
         3) Una línea con los símbolos del alfabeto separados por espacios.
         4) Una línea con los estados finales separados por espacios.
         5) n líneas con la tabla de transiciones, cada línea:
            <estado> <destino_simbolo_1> ... <destino_simbolo_k>
    Retorna una lista con tuplas (n, alphabet, final_states, transition_table).
    """
    cases = []
    
    # 1) Leer el número de casos
    line = input().strip()
    c = int(line)  # Número de casos
    
    for _ in range(c):
        # 2) Número de estados
        n = int(input().strip())
        
        # 3) Alfabeto
        alphabet = input().strip().split()
        
        # 4) Estados finales
        final_states = set(map(int, input().strip().split()))
        
        # 5) Tabla de transiciones
        transition_table = [None] * n
        for _ in range(n):
            row = input().strip().split()
            if len(row) != len(alphabet) + 1:
                raise ValueError("Error: La fila de transiciones no coincide con el tamaño del alfabeto + 1.")
            
            state_id = int(row[0])
            destinations = list(map(int, row[1:]))
            transition_table[state_id] = destinations
        
        cases.append((n, alphabet, final_states, transition_table))
    
    return cases

def initialize_mark_table(n, final_states):
    """
    Crea una matriz (n x n) para marcar pares de estados distinguibles.
    table[i][j] = True indica que (i, j) es un par distinguible.
    """
    table = [[False] * n for _ in range(n)]
    # Marca pares (i, j) donde uno es final y el otro no
    for i in range(n):
        for j in range(i + 1, n):
            if (i in final_states) != (j in final_states):
                table[i][j] = True
    return table

def fill_mark_table(n, alphabet, transition_table, table):
    """
    Rellena la tabla de marcación (método de la tabla de llenado).
    Marca como distinguibles los pares (i, j) que llevan a pares ya marcados.
    Se repite hasta no encontrar cambios.
    """
    changed = True
    while changed:
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                if not table[i][j]:
                    # Revisamos cada símbolo del alfabeto
                    for symbol_index in range(len(alphabet)):
                        next_i = transition_table[i][symbol_index]
                        next_j = transition_table[j][symbol_index]
                        
                        # Aseguramos el orden (menor, mayor) al acceder a la tabla
                        if next_i > next_j:
                            next_i, next_j = next_j, next_i
                        
                        # Si las transiciones llevan a un par marcado, marcamos (i, j)
                        if next_i != next_j and table[next_i][next_j]:
                            table[i][j] = True
                            changed = True
                            break

def get_equivalent_pairs(n, table):
    """
    Retorna todos los pares (i, j) con i < j que NO están marcados,
    es decir, los estados equivalentes.
    """
    equivalent_pairs = []
    for i in range(n):
        for j in range(i + 1, n):
            if not table[i][j]:
                equivalent_pairs.append((i, j))
    return equivalent_pairs

def main():
    # 1) Leer los casos desde la consola
    cases = parse_input()
    
    # 2) Procesar cada caso
    results = []
    for n, alphabet, final_states, transition_table in cases:
        # a) Inicializamos la tabla de marcación
        table = initialize_mark_table(n, final_states)
        
        # b) Llenamos la tabla (marcamos pares distinguibles)
        fill_mark_table(n, alphabet, transition_table, table)
        
        # c) Obtenemos los pares equivalentes
        eq_pairs = get_equivalent_pairs(n, table)
        
        # d) Formateamos la salida
        if eq_pairs:
            line = " ".join(f"({i}, {j})" for i, j in eq_pairs)
        else:
            line = ""
        
        results.append(line)
    
    # 3) Imprimir resultados
    for line in results:
        print(line)

if __name__ == "__main__":
    main()
